import requests
import json

# Thingsboard server details
tb_server = 'http://app.controlytics.ai:8080'
tb_token = 'w8gt6DArTgzOokKptSaU'

# Temperatures to send
temperatures = [20,10,5,3,6]

# Send each temperature as a separate telemetry data point
for temperature in temperatures:
    # Data to send
    data = {
        "temperature": temperature
    }

    # Convert data to JSON format
    payload = json.dumps(data)

    # Set the request headers
    headers = {
        'Content-Type': 'application/json'
    }

    # Send POST request to Thingsboard server
    url = f"{tb_server}/api/v1/{tb_token}/telemetry"
    response = requests.post(url, data=payload, headers=headers)

    # Check response status
    if response.status_code == 200:
        print(f"Temperature {temperature} added successfully!")
    else:
        print(f"Failed to add temperature {temperature}. Status code:", response.status_code)
