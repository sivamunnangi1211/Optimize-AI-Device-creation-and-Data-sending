import requests
import json
import time

# Thingsboard server details
tb_server = 'http://app.controlytics.ai:8080'
tb_token = '8tfDZY0WnPUob1IlM2wp'

# Temperature values
temperature_values = [44, 50, 33, 22, 55, 11]

# Data to send with timestamps
data = []
current_timestamp = int(time.time() * 1000)
for temperature in temperature_values:
    data.append({"ts": current_timestamp, "values": {"temperature": temperature}})
    current_timestamp += 1000  # Increment timestamp by 1 second (1000 milliseconds)

# Convert data to JSON format
payload = json.dumps(data)

# Set the request headers
headers = {
    'Content-Type': 'application/json'
}

# Send POST request to Thingsboard server
url = f"{tb_server}/api/v1/{tb_token}/timeseries"
response = requests.post(url, data=payload, headers=headers)

# Check response status
if response.status_code == 200:
    print("Data added successfully!")
else:
    print("Failed to add data. Status code:", response.status_code)
