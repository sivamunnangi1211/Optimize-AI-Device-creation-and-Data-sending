import requests
import json

# Thingsboard server details
tb_server = 'http://app.controlytics.ai:8080'
tb_token = '6gx7570fghblcpi2qygm'

# Data to send
data = {
    "temperature": [45, 50, 33, 32, 21]
}

# Convert data to JSON format
payload = json.dumps(data)

# Set the request headers
headers = {
    'Content-Type': 'application/json'
}

# Send POST request to Thingsboard server
url = f"{tb_server}/api/v1/{tb_token}/telemetry"
response = requests.post(url, data=payload, headers=headers)

# Check response status
if response.status_code == 200:
    print("Data added successfully!")
else:
    print("Failed to add data. Status code:", response.status_code)
