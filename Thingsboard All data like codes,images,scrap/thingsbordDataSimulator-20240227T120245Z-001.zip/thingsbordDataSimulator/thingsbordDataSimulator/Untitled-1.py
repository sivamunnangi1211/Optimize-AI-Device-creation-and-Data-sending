#!/usr/bin/env python3
from RPiMCP23S17.MCP23S17 import MCP23S17
from bitstring import BitArray
from flask import Flask, render_template
import random
import threading
import os
import logger
import time
import spidev

app = Flask(__name__)

mcp = MCP23S17(bus=0x00, pin_cs=0x00, device_id=0x00)
mcp.open()
mcp._writeRegister(0x0C, 0x00)
mcp._writeRegister(0x0D, 0x00)

for x in range(0, 16):
    mcp.setDirection(x, mcp.DIR_INPUT)


def ZeroPad(array):
    for x in range(array.len, 8):
        array.prepend('0b0')
    return array


def ReadGPIO():
    while True:
        BankA = ZeroPad(BitArray(bin(mcp._readRegister(0x12))))
        BankB = ZeroPad(BitArray(bin(mcp._readRegister(0x13))))

        print("BankA")
        print(BankA.bin)  # show read pins for GPA0 until GPA7

        print("BankB")
        print(BankB.bin)  # show read pins for GPB0 until GPB7

        # Rest of the GPIO reading code goes here

        # Sleep for some time before reading GPIO again
        time.sleep(0.3)


@app.route('/')
def index():
    return render_template('index.html', var1=var1, var2=var2, var3=var3, var4=var4, var5=var5, var6=var6,
                           var7=var7, var8=var8, var9=var9, var10=var10, var11=var11, var12=var12)


# Initialize the variables with random values between 0 and 3
var1 = random.randint(0, 3)
var2 = random.randint(0, 3)
var3 = random.randint(0, 3)
var4 = random.randint(0, 3)
var5 = random.randint(0, 3)
var6 = random.randint(0, 3)

# Initialize the additional variables with random values between 0 and 600
var7 = random.randint(0, 600)
var8 = random.randint(0, 600)
var9 = random.randint(0, 600)
var10 = random.randint(0, 600)
var11 = random.randint(0, 600)
var12 = random.randint(0, 600)


# Function to update variables 1-6 with random values between 0 and 3
def update_variables1():
    global var1, var2, var3, var4, var5, var6
    while True:
        var1 = random.randint(0, 3)
        var2 = random.randint(0, 3)
        var3 = random.randint(0, 3)
        var4 = random.randint(0, 3)
        var5 = random.randint(0, 3)
        var6 = random.randint(0, 3)


# Function to update variables 7-12 with random values between 0 and 600
def update_variables2():
    global var7, var8, var9, var10, var11, var12
    while True:
        var7 = random.randint(0, 600)
        var8 = random.randint(0, 600)
        var9 = random.randint(0, 600)
        var10 = random.randint(0, 600)
        var11 = random.randint(0, 600)
        var12 = random.randint(0, 600)


if __name__ == '__main__':
    # Start threads to update the variables and read GPIO
    variable_thread1 = threading.Thread(target=update_variables1)
    variable_thread2 = threading.Thread(target=update_variables2)
    gpio_thread = threading.Thread(target=ReadGPIO)
    variable_thread1.start()
    variable_thread2.start()
    gpio_thread.start()

    app.run(host='0.0.0.0', port=3000, debug=True)  # Set debug=True for Flask to show debugging information

